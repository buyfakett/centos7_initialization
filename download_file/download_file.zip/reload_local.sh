openresty -t
systemctl reload openresty