docker exec -it nginx nginx -s reload
